package kr.or.ddit.loop;

public class WhileTest1 {

	public static void main(String[] args) {
		
		//1~10���� ���
		//1,2,3,4,5,6,7,8,9,10
		
		System.out.println("for-----");
		for(int i=1; i<=10; i++) {
			System.out.println(i);
		}
		
		System.out.println("while-----");
        int i=1;
        while (i<=10) {
        	System.out.println(i);
        	i++;
        }
		
		
		
		// �ʱ��
		// while (���ǽ�){
		//     ���๮1
	   //    ���๮2
	   //   ������ 
	   // }      
	   
		     
		     
		
		

	}

}
