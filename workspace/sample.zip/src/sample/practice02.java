package sample;

import java.util.Scanner;

public class practice02 {

	public static void main(String[] args) {
	   String name = "���ڹ�";
	   int age = 25;
	   String tel1="010", tel2="123", tel3="4567";
	   
	   System.out.println("�̸�: "+"���ڹ�");
	   System.out.print("����: "+"25 ");
	   //System.out.printf("��ȭ: "+"010"+"123"+"4567");
	   System.out.printf("��ȭ : %1$s-%2$s-%3$s","010","123","4567");
	   
	   

	}
}




